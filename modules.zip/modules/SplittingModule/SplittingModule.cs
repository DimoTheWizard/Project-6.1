/*using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace modules
{
    public class SplittingModule
    {
        private XDocument xml;

        SplittingModule(XDocument xml) {
            this.xml = xml;
        }

        public addCategory(Categories category) {
            this.xml.category = category;
        }
  
    }
}*/